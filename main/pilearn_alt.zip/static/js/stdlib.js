function $post(what, action, field, param, cb) {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            if(cb) {
                cb(this.responseText);
            }
        } else if (this.readyState == 4) {
            if(cb) {
                cb(this.responseText);
            }
        }
    };
    xhttp.open("POST", "/"+what+"/"+action+"/"+field, true);
    xhttp.setRequestHeader("Content-Type", "application/json");
    xhttp.send(JSON.stringify(param));
}