report_btn = document.getElementById(flagging_id + "-report_btn");
if (report_btn != null) {
    report_btn.addEventListener("click", function () {
        elements = [document.getElementById(flagging_id + "-spam_reason"), document.getElementById(flagging_id + "-offensive_reason"), document.getElementById(flagging_id + "-fraud_reason"), document.getElementById(flagging_id + "-other_reason")]
        reason = "";
        for (var i = 0; i < elements.length; i++) {
            if (elements[i] == null) {
                continue;
            }
            if (elements[i].checked) {
                reason = elements[i].value;
                break;
            }
        }
        message = document.getElementById(flagging_id + "-message").value;
        $post("flag", "add", "user", {
            "type": "report",
            "reason": reason,
            "message": message,
            "user-id": flagging_user
        }, function (resp) {
            master = document.getElementById(flagging_id + "-content-master");
            _ = document.createElement("div");
            if (resp == "{ok}") {
                _.classList.add("success");
                while (master.firstChild) {
                    master.removeChild(master.firstChild);
                }
                _.innerText = "Vielen Dank für die Meldung dieses Benutzers. Ein Benutzer mit genügend Reputation wird sich diese Meldung anschauen und eine entsprechende Aktion durchführen.";
                master.appendChild(_);
                __ = document.createElement("button");
                __.innerText = "Ok";
                __.classList.add("less-annoying");
                __.addEventListener("click", function () {
                    document.getElementById(flagging_id).classList.remove('open');
                })
                master.appendChild(__);
            } else {
                if (master.lastChild.classList && master.lastChild.classList.contains("error")) {
                    master.removeChild(master.lastChild);
                }
                _.classList.add("error");
                _.innerText = "Uups. Irgendetwas ist schiefgelaufen. Versuch es bitte erneut. Der Server meldet:";
                __ = document.createElement("pre");
                __.innerText = resp;
                _.appendChild(__);
                master.appendChild(_);
            }
        })
    })
}