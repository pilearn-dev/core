function edit(field) {
    element = document.getElementById(field);
    if(element == null) {
        return;
    }
    if (field == "password") {
        current_value = "";
    } else {
        current_value = element.innerText;
    }
    while (element.firstChild) {
        element.removeChild(element.firstChild);
    }
    input_element = document.createElement("input");
    input_element.classList.add("inline")
    if (field == "password") {
        input_element.setAttribute("placeholder", "Bitte Passwort neu eingeben!")
        input_element.type = "password"
    }
    input_element.value = current_value;
    input_element.addEventListener("keypress", function(e) {
        if(e.key == "Enter") {
            $post("user", "set", field, {"new_value": input_element.value, "userid": user_id});
            element.removeChild(input_element);
            if (field == "password") {
                element.innerText = "*****"
            } else {
                element.innerText = input_element.value
            }
        } else if (e.keyCode == 27) {
            element.removeChild(input_element);
            if (field == "password") {
                element.innerText = "*****"
            } else {
                element.innerText = current_value
            }
        }
    })
    element.appendChild(input_element);
    input_element.focus();
}