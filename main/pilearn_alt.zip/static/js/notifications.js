function toggle_notifications() {
    el = document.getElementById("notification-area");
    if (el.classList.contains("shown")) {
        el.classList.remove("shown");
        this.classList.remove("open");
    } else {
        this.classList.add("open");
        el.classList.add("shown");
        pos = this.getBoundingClientRect();
        console.log(pos);
        x = pos.x;
        y = pos.y + pos.height + 1;
        el.style.top = String(y) + "px";
        el.style.left = String(x) + "px";
        while (el.firstChild) {
            el.removeChild(el.firstChild);
        }
        _ = document.createElement("h3");
        _.innerText = "Benachrichtigungen";
        el.appendChild(_);
        if (NOTIFICATIONS.length == 0) {
            _ = document.createElement("p");
            _.innerText = "keine Benachrichtigungen";
            el.appendChild(_);
        }
        if (NOTIFICATIONS.length != 0)
        {
            the_input = document.createElement("input");
            the_input.classList.add("inline");
            the_input.setAttribute("placeholder", "Suche");
            el.appendChild(the_input);
        }
        all_sub_els = [];
        for (var i = 0; i < NOTIFICATIONS.length; i++) {
            not_ = NOTIFICATIONS[i];
            _nel_ = document.createElement("a");
            _nel_.setAttribute("href", not_.link);
            _n2 = document.createElement("div");
            if (not_.visibility == 0) {
                _n2.classList.add("lower-visibility")
            }
            _n2.classList.add(not_.type);
            _n2.innerText = not_.message
            if (not_.visibility == 0) {
                _n2.classList.add("lower-visibility")
            }
            _nel_.appendChild(_n2);
            if (not_.visibility == 1) {
                el.insertBefore(_nel_, el.firstChild.nextSibling.nextSibling);
            } else {
                el.appendChild(_nel_);
            }
            all_sub_els.push(_nel_);
        }
        if (NOTIFICATIONS.length != 0) {
            _ = document.createElement("p");
            _.innerText = "Insgesamt " + String(NOTIFICATIONS.length) + " Benachrichtigungen";
            el.insertBefore(_, el.firstChild.nextSibling.nextSibling);
            all_sub_els.push(_);
            the_input.addEventListener("keyup", function (event) {
                for (var j = 0; j < all_sub_els.length; j++) {
                    el.removeChild(all_sub_els[j]);
                }
                all_sub_els = [];
                query = this.value.trim();
                var amount = 0;
                for (var i = 0; i < NOTIFICATIONS.length; i++) {
                    not_ = NOTIFICATIONS[i];
                    if ((query == "") || (not_.message.indexOf(query) != -1)) {
                        amount++;
                        _nel_ = document.createElement("a");
                        _nel_.setAttribute("href", not_.link);
                        _n2 = document.createElement("div");
                        if (not_.visibility == 0) {
                            _n2.classList.add("lower-visibility")
                        }
                        _n2.classList.add(not_.type);
                        _n2.innerText = not_.message
                        if (not_.visibility == 0) {
                            _n2.classList.add("lower-visibility")
                        }
                        _nel_.appendChild(_n2);
                        if (not_.visibility == 1) {
                            el.insertBefore(_nel_, el.firstChild.nextSibling.nextSibling);
                        } else {
                            el.appendChild(_nel_);
                        }
                        all_sub_els.push(_nel_);
                    }
                }
                if (query != "") {
                    _ = document.createElement("p");
                    _.innerText = "Gefunden: " + String(amount) + " von " + String(NOTIFICATIONS.length);
                    el.insertBefore(_, el.firstChild.nextSibling.nextSibling);
                    all_sub_els.push(_);
                } else {
                    _ = document.createElement("p");
                    _.innerText = "Insgesamt " + String(NOTIFICATIONS.length) + " Benachrichtigungen";
                    el.insertBefore(_, el.firstChild.nextSibling.nextSibling);
                    all_sub_els.push(_);
                }
            })
        }
    }
}
el = document.getElementById("notification-trigger")
for (var i = 0; i < NOTIFICATIONS.length; i++) {
    if (NOTIFICATIONS[i].visibility == 1) {
        el.classList.add("hasthere");
        break;
    }
}
el.addEventListener("click", toggle_notifications);