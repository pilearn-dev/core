import sqlite3 as lite

con = None

# Cleanup-script #1: ResetMyAccount
try:
    con = lite.connect('databases/user.db')
    cur = con.cursor()
    cur.execute("""
    UPDATE user SET state='1', role='d' WHERE id='1';
    """)
    con.commit()
except SyntaxError as e:
    print("Error %s:" % e.args)
finally:
    if con:
        con.close()

# Cleanup-script #1: DestroyNominatedPosts
try:
    con = lite.connect('databases/forum.db')
    cur = con.cursor()
    cur.execute("""
    DELETE FROM fo_articles WHERE state=-5;
    """)
    cur.execute("""
    DELETE FROM fo_answers WHERE state=-5;
    """)
    con.commit()
except SyntaxError as e:
    print("Error %s:" % e.args)
finally:
    if con:
        con.close()

# END OF FILE