import os
import sqlite3 as lite
from flask import Flask, request, session, g, redirect, url_for, abort, \
     render_template, flash
import priv

def index(stop, value=None):
    return render_template('help/index.html', stop=stop, title="Hilfe – Überblick", thispage="help")

def highqual(stop, value=None):
    return render_template('help/highqual.html', stop=stop, title="Hilfethema – Hochwertige Inhalte", thispage="help")

def concept(stop, value=None):
    return render_template('help/concept.html', stop=stop, title="Hilfethema – Konzept", thispage="help")

def reputation(stop, value=None):
    return render_template('help/reputation.html', stop=stop, title="Hilfethema – Reputatinssystem", thispage="help")

def privileges(stop, value=None):
    data = priv.note_data
    data = sorted(data, key=lambda x:stop["priv"][x["id"]])
    return render_template('help/privileges.html', stop=stop, data=data, title="Hilfethema – Privilegien", thispage="help")

views = {
    "index": index,
    "highqual": highqual,
    "concept": concept,
    "reputation": reputation,
    "privileges": privileges
}