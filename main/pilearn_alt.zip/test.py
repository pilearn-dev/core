import sqlite3 as lite
import sys

con = None

try:
    #con = lite.connect('databases/forum.db')
    con = lite.connect('databases/courses.db')
    
    cur = con.cursor()
    con.executescript("""
    """)
    con.commit()

    #cur.execute("CREATE TABLE fo_answers (id INTEGER PRIMARY KEY, forum_id INT, article_id INT, state TINYINT, award SMALLINT, is_accepted TINYINT, author INT, score INT, content TEXT, modMessage TEXT, deleteReason VARCHAR(100))");

    #cur.execute("INSERT INTO fo_articles (forum_id, title, state, award, accepted_answer, locked, pinned, election, author, score, content, tags, closeReason, closeMessage, lockMessage, modMessage, deleteReason) VALUES ('0', 'π-Learn-FAQ', '1', '0', '0', '0', '1', '0', '1', '0', 'Herzlich Willkommen bei π-Learn. Um dir den Einstieg etwas leichter zu machen, haben wir hier einige Punkte zusammengetragen, die dir helfen sollen, dich auf π-Learn zurechtzufinden:', '[faq]|[for-beginner]', '', '', '', '', '')")
    #cur.execute("UPDATE fo_articles SET id=1 WHERE id=2")
    #cur.execute("UPDATE user SET role='d' WHERE id=1")
    #cur.execute()
    #data = cur.fetchone()
    #data = cur.fetchall()
    #print(data)
    #cur.lastrowid
    con.commit()
    
except SyntaxError as e:
    
    print("Error %s:" % e.args)
    sys.exit(1)
    
finally:
    
    if con:
        con.close()