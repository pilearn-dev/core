note_data = [
    {
        "name": "Alle Benachrichtigungen zeigen",
        "desc": "Für alle Nutzer, die dieses Privileg noch nicht erreicht haben, werden Benachrichtigungen ausgeblendet, sobald sie erledigt sind.",
        "id": "general_showAllNotifications",
        "type": "honor"
    },
    {
        "name": "Benutzer melden",
        "desc": "Du kannst verdächtiges Verhalten eines Nutzers über einen Knopf auf der Benutzerseite melden.",
        "id": "general_reportUser",
        "type": "moderation"
    },
    {
        "name": "Benutzer verwarnen",
        "desc": "Du kannst einen Benutzer über einen Knopf auf der Benutzerseite verwarnen. Der Benutzer erhält eine Benachrichtigung über diese Verwarnung. Wird ein Nutzer 3 mal verwarnt, wird er automatisch gesperrt.",
        "id": "general_warnUser",
        "type": "moderation"
    },
    {
        "name": "Benutzer sperren",
        "desc": "Du kannst einen Benutzer über einen Knopf auf der Benutzerseite sperren. Der Benutzer kann daraufhin nicht mehr an einem Kurs oder im Forum teilnehmen. Seine Reputation wird während der Sperrzeit auf 1 gesetzt, so dass er auch anderweitig nicht an π-Learn teilnehmen kann.",
        "id": "general_banUser",
        "type": "moderation"
    },
    {
        "name": "Benutzer entsperren",
        "desc": "Du kannst einen Benutzer, der gesperrt ist auch wieder entsperren.",
        "id": "general_unbanUser",
        "type": "moderation"
    },
    {
        "name": "Reputation verschenken",
        "desc": "Du kannst einen Teil deiner Reputation an einen anderen Nutzer verschenken. Du verlierst diese Reputation damit und sie wird dem anderen Nutzer unverzüglich hinzugefügt.",
        "id": "general_giveRep",
        "type": "honor"
    },
    {
        "name": "Benutzer löschen",
        "desc": "Du kannst gesperrte Nutzer oder Nutzer, die mindestens fünf Mal verwarnt wurden (und danach wieder entsperrt wurden) löschen. Moderatoren können alle Benutzer löschen.",
        "id": "general_deleteUser",
        "type": "moderation"
    },
    {
        "name": "Wahlleiter",
        "desc": "Du kannst im globalen Forum sogenannte Wahlen posten. Mehr dazu [hier](/help/elections)",
        "id": "general_electorate",
        "type": "moderation"
    },
    {
        "name": "Ankündigungen machen",
        "desc": "Du kannst im globalen Forum Ankündigungen posten, die an jeden Nutzer verschickt werden.",
        "id": "general_makeAnnouncements",
        "type": "moderation"
    },
    {
        "name": "Automatischer Moderator",
        "desc": "Dein Account wird jetzt als Moderator-Account angezeigt",
        "id": "general_autoMod",
        "type": "honor"
    },
    # Kursprivilegien
    {
        "name": "Kommentare zu Kursen hinzufügen",
        "desc": "Du kannst Kommentare zu Kursen hinzufügen. (Verbesserungsvorschläge, Danksagungen, ...)",
        "id": "course_comment",
        "type": "participiation"
    },
    {
        "name": "Kommentare von Kursen bewerten",
        "desc": "Du kannst Kommentare von Kursen bewerten, wenn du sie hilfreich findest, oder mit der Meinung übereinstimmst.",
        "id": "course_commentVote",
        "type": "participiation"
    },
    {
        "name": "Kurse bewerten",
        "desc": "Du kannst Kurse bewerten.",
        "id": "course_vote",
        "type": "participiation"
    },
    {
        "name": "Kurse vorschlagen",
        "desc": "Du kannst neue Kurse vorschlagen.",
        "id": "course_propose",
        "type": "participiation"
    },
    {
        "name": "Bearbeitungen von Kursseiten vorschlagen",
        "desc": "Du kannst die Bearbeitung von Kursseiten vorschlagen.",
        "id": "course_proposeEdit",
        "type": "participiation"
    },
    {
        "name": "Kurse bearbeiten",
        "desc": "Du kannst die Kursseiten bearbeiten und Bearbeitungsvorschläge moderieren. Dazu erhältst du Zugriff auf die entsprechende Moderationsliste.",
        "id": "course_reviewEdits",
        "type": "participiation"
    },
    {
        "name": "Kurse erstellen",
        "desc": "Du kannst eigenmächtig neue Kurse erstellen und Kursvorschläge moderieren. Dazu erhältst du Zugriff auf die entsprechende Moderationsliste.",
        "id": "course_create",
        "type": "participiation"
    },
    {
        "name": "Kurse löschen",
        "desc": "Du kannst Kurse löschen, die eine Bewertung von kleiner als minus drei haben. Moderatoren können alle Kurse löschen.",
        "id": "course_remove",
        "type": "participiation"
    },
    # Forum-Berechtigungen
    {
        "name": "An geschützten Posts mitarbeiten",
        "desc": "Du kannst jetzt an geschützten Posts mitarbeiten.",
        "id": "forum_workAtProtected",
        "type": "honor"
    },
    {
        "name": "Kommentare schreiben",
        "desc": "Du kannst jetzt überall kommentieren. (Davor nur bei eigenen Posts)",
        "id": "forum_comment",
        "type": "participiation"
    },
    {
        "name": "Posts melden",
        "desc": "Du kannst jetzt verdächtige Posts melden.",
        "id": "forum_flag",
        "type": "moderation"
    },
    {
        "name": "Posts positiv bewerten",
        "desc": "Du kannst jetzt Posts positiv bewerten (+1)",
        "id": "forum_voteUp",
        "type": "moderation"
    },
    {
        "name": "Posts negativ bewerten",
        "desc": "Du kannst jetzt Posts negativ bewerten (-1)",
        "id": "forum_voteDown",
        "type": "moderation"
    },
    {
        "name": "Post-Bearbeitung vorschlagen",
        "desc": "Du kannst jetzt Bearbeitungen von Posts vorschlagen.",
        "id": "forum_proposeEdit",
        "type": "participiation"
    },
    {
        "name": "Direkt mit anderen Nutzern chatten",
        "desc": "Du kannst jetzt mit anderen Nutzern chatten.",
        "id": "forum_directChat",
        "type": "participiation"
    },
    {
        "name": "Posts bearbeiten",
        "desc": "Du kannst jetzt Posts bearbeiten und Bearbeitungsvorschläge moderieren. Dazu erhältst du Zugriff auf die entsprechende Moderationsliste.",
        "id": "forum_reviewEdits",
        "type": "participiation"
    },
    {
        "name": "Antworten verstecken",
        "desc": "Du kannst jetzt niedrigqualitative oder verletzende Antworten verstecken. Dazu sind zwei Stimmen von Benutzern mit diesem Privileg notwendig. Du kannst außerdem Meldungen von anderen Nutzern für Antworten moderieren. Dazu erhältst du Zugriff auf die entsprechende Moderationsliste.",
        "id": "forum_hideAnswer",
        "type": "moderation"
    },
    {
        "name": "Fragen schützen",
        "desc": "Du kannst jetzt Fragen schützen, sodass ein Nutzer mindestens 5 Reputationspunkte haben muss, um zu antworten.",
        "id": "forum_setProtection",
        "type": "moderation"
    },
    {
        "name": "Belohnung aussetzen",
        "desc": "Du kannst jetzt einen Teil deiner Reputation als Belohnung aussetzen. Mehr Informationen findest du [hier](/help/award)",
        "id": "forum_setAward",
        "type": "honor"
    },
    {
        "name": "Fragen schließen",
        "desc": "Du kannst jetzt niedrigqualitative oder verletzende Fragen verstecken. Dazu sind drei Stimmen von Benutzern mit diesem Privileg notwendig. Du kannst außerdem Meldungen von anderen Nutzern für Fragen moderieren. Dazu werden jetzt auch Fragen in der Moderationsliste angezeigt..",
        "id": "forum_closeQuestion",
        "type": "moderation"
    },
    {
        "name": "Fragen sperren",
        "desc": "Du kannst jetzt Fragen sperren, damit sie nicht mehr bearbeitet oder beantwortet werden können und damit niemand mehr abstimmen kann.",
        "id": "forum_setLock",
        "type": "moderation"
    }
]