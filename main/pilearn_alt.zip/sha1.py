import hashlib
def sha1(string):
    string = string.encode("utf-8")
    m = hashlib.sha256()
    m.update(string)
    return m.hexdigest()