import json, re
import sqlite3 as lite
from flask import Flask, request, session, redirect, url_for, abort, \
     render_template
from flaskext.markdown import Extension, Markdown
from markdown.preprocessors import Preprocessor
from markdown.postprocessors import Postprocessor
import courses, user, help, review, forum
app = Flask(__name__)
app.config.update(dict(
    SECRET_KEY='R6a9xRtyH2Tu55zX3Sn8'
))
md = Markdown(app, extensions=["iconfonts(prefix=fa-, base=fa)"])

moderator_tags = ["status:in-arbeit", "status:erledigt", "status:abgelehnt", "faq", "wahl"]
banned_tags = []

class MDExtPreProcessor(Preprocessor):
    def run(self, lines):
        new_lines = []
        for line in lines:
            m = re.findall(r"\[\#([a-zA-Z:0-9-]+?)\]", line)
            for i in m:
                if i in moderator_tags:
                    line = line.replace("[#"+i+"]", "<span class='tag moderator-tag'>"+i+"</span>")
                elif i in banned_tags:
                    line = line.replace("[#"+i+"]", "(( banned tag has been replaced ))")
                else:
                    line = line.replace("[#"+i+"]", "<span class='tag'>"+i+"</span>")
            new_lines.append(line)
        return new_lines

class MDExtPostProcessor(Postprocessor):
    def run(self, lines):
        new_lines = []
        for line in lines:
            m = re.match(r"(\{\! deleted \"(.*?)\" \"(.*?)\" \!\})", line)
            if m:
                if m.group(2) == "by-mod":
                    x = m.group(3)
                    x = x.split(":")
                    x = {
                        "name": x[0],
                        "id": x[1]
                    }
                else:
                    x = {}
                line = line.replace(m.group(1), render_template("snippets/deleted-post.html", fromwho=m.group(2), extra=x))
            m = re.match(r"(\{\! locked ([1-3]) \"(.*?)\" \"(.*?)\" \!\})", line)
            if m:
                x = m.group(3)
                x = x.split(":")
                x = {
                    "name": x[0],
                    "id": x[1]
                }
                line = line.replace(m.group(1), render_template("snippets/locked-post.html", level=m.group(2), fromwho=x, reason=m.group(4)))
            m = re.match(r"(\{\! award ([0-9]+) \!\})", line)
            if m:
                line = line.replace(m.group(1), render_template("snippets/award-post.html", amount=m.group(2)))
            new_lines.append(line)
        return new_lines

@md.extend()
class ExtensionPreRegisterer(Extension):
     def extendMarkdown(self, md, md_globals):
        md.preprocessors.add('prover_block',
                            MDExtPreProcessor(md),
                            '_begin')
        md.registerExtension(self)

md.register_extension(ExtensionPreRegisterer)

@md.extend()
class ExtensionPostRegisterer(Extension):
     def extendMarkdown(self, md, md_globals):
        md.preprocessors.add('prover_block',
                            MDExtPostProcessor(md),
                            '_begin')
        md.registerExtension(self)

md.register_extension(ExtensionPostRegisterer)

f = open("privileges.json", "r")
PRIV_DATA = json.loads(f.read())
f.close()

def get_standard_options():
    userdata = user.model__get_user_info(session['login'])
    show_all_notifications = (userdata["reputation"] >= PRIV_DATA["general_showAllNotifications"])
    messages = user.model__get_user_notifications(session['login'], show_all_notifications)
    is_dev = userdata["role"] == "d"
    if userdata["role"] == "d":
        userdata["role"] = "a"
    if userdata["state"] == -2:
        session.pop('login', None)
        abort(403)
    return {
        "username": userdata["realname"],
        "userid": userdata["id"],
        "userrep": userdata["reputation"],
        "userrole": userdata["role"],
        "user_is_dev": is_dev,
        "priv": PRIV_DATA,
        "messages": messages,
        "modtags": moderator_tags
    }


@app.route("/")
def index():
    if session.get('login') is None:
        return redirect(url_for('login'))

    stop = get_standard_options()


    return render_template('index.html', stop=stop, title="Startseite", thispage="index")

@app.route("/~dev/sql", methods=['GET', 'POST'])
def __dev_sql():
    if session.get('login') is None:
        return redirect(url_for('login'))

    stop = get_standard_options()

    if not stop["user_is_dev"]:
        abort(404)

    if request.form["sql_file"] in ["courses.db", "user.db", "forum.db"]:
        file = request.form["sql_file"]
        sql = request.form["sql_sql"]

        try:
            con = lite.connect('databases/'+file)
            cur = con.cursor()
            cur.execute(sql)
            lr = cur.fetchall()
            con.commit()
        except lite.Error as e:
            lr = [["Fehler:", str(e)]]
        except lite.Warning as e:
            lr = [["Achtung:", str(e)]]
    else:
        lr = [["Info", "Keine Abfrage gestartet"]]
        file = sql = ""

    return render_template('~dev/sql.html', stop=stop, title="Entwicklermodus", thispage="sql", last_response=lr, last_sql=sql, last_file=file)

@app.route('/course/<string:action>', methods=['GET', 'POST'])
@app.route('/course/<string:action>/<string:value>', methods=['GET', 'POST'])
def course_(action, value=None):
    if session.get('login') is None:
        return redirect(url_for('login'))

    stop = get_standard_options()


    if action in courses.views:
        return courses.views[action](stop, value)
    abort(405)

@app.route('/forum/f<int:forumid>/<string:page>', methods=['GET', 'POST'])
@app.route('/forum/f<int:forumid>/<string:page>/<string:action>', methods=['GET', 'POST'])
def forum_(forumid, page, action=None):
    if session.get('login') is None:
        return redirect(url_for('login'))

    stop = get_standard_options()
    return forum.the_forum(stop, forumid, page, action)

@app.route('/user/<string:action>', methods=['GET', 'POST'])
@app.route('/user/<string:action>/<string:value>', methods=['GET', 'POST'])
@app.route('/user/<string:action>/<string:value>', methods=['GET', 'POST'])
def user_(action, value=None):
    if session.get('login') is None:
        return redirect(url_for('login'))

    stop = get_standard_options()


    if action in user.views:
        return user.views[action](stop, value)
    abort(405)

@app.route('/help')
@app.route('/help/<string:action>')
def help_(action="index", value=None):
    if session.get('login') is None:
        return redirect(url_for('login'))

    stop = get_standard_options()


    if action in help.views:
        return help.views[action](stop, value)
    abort(405)

@app.route('/review')
@app.route('/review/<string:action>')
@app.route('/review/<string:action>/<string:value>', methods=['GET', 'POST'])
def review_(action="index", value=None):
    if session.get('login') is None:
        return redirect(url_for('login'))

    stop = get_standard_options()


    if action in review.views:
        return review.views[action](stop, value)
    abort(405)

@app.route("/notification/<int:id>")
def notification(id):
    not_data = user.model__get_notification(id)
    if not_data is None:
        abort(400)
    else:
        user.model__set_notification_hidden(id)
        link = not_data["link"]
        return redirect(link)

@app.route("/flag/<method>/<type>", methods=['GET', 'POST'])
def flag(method, type):
    return "{ok}"

@app.route("/login", methods=['GET', 'POST'])
def login():
    error = False
    if request.method == 'POST':
        if request.form['email'] == "":
            data = user.model__try_login(request.form['username'], request.form['password'])
            if data == -4:
                error = "forbidden"
            elif data == -3:
                error = "not-found"
            else:
                user_id = data
        if not error:
            session['login'] = user_id
            return redirect(url_for('index'))
    return render_template('login.html', error=error, stop={"priv": PRIV_DATA, "userrep": 0, "messages":[]}, title="Anmelden")

@app.route('/logout')
def logout():
    session.pop('login', None)
    return redirect(url_for('index'))

@app.errorhandler(400)
def error400(x):
    if session.get('login') is None:
        return redirect(url_for('login'))

    stop = get_standard_options()


    return render_template('error400.html', stop=stop, title="400 Ungültige Anfrage")

@app.errorhandler(404)
def error404(x):
    if session.get('login') is None:
        return redirect(url_for('login'))

    stop = get_standard_options()


    return render_template('error404.html', stop=stop, title="404 Nicht gefunden")

@app.errorhandler(405)
def error405(x):
    if session.get('login') is None:
        return redirect(url_for('login'))

    stop = get_standard_options()


    return render_template('error405.html', stop=stop, title="405 Ungültiger Zugriffsmethode")

@app.errorhandler(500)
def error500(x):
    if session.get('login') is None:
        return redirect(url_for('login'))

    stop = get_standard_options()


    return render_template('error500.html', stop=stop, title="500 Server-Fehler")