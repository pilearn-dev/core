import os, json
import sqlite3 as lite
from flask import Flask, request, session, g, redirect, url_for, abort, \
     render_template, flash
from sha1 import sha1

def model__get_user_info(user_id):
    try:
        con = lite.connect('databases/user.db')
        con.row_factory = lite.Row
        cur = con.cursor()
        cur.execute("SELECT * FROM user WHERE id='"+str(user_id)+"'")
        data = cur.fetchone()
        if data is None:
            return
        return {
            "id": data['id'],
            "name": data['name'],
            "realname": data['realname'],
            "email": data['email'],
            "state": data['state'],
            "role": data['role'],
            "reputation": data['reputation'],
            "profile_image": ""
        }
    except lite.Error as e:
        raise lite.Error from e
    finally:
        if con:
            con.close()

def model__get_user_notifications(user_id, all=False):
    try:
        con = lite.connect('databases/user.db')
        con.row_factory = lite.Row
        cur = con.cursor()
        if all:
            cur.execute("SELECT * FROM notifications WHERE user_id=?", (user_id, ))
        else:
            cur.execute("SELECT * FROM notifications WHERE user_id=? AND visible='1'", (user_id, ))
        return_value = []
        data = cur.fetchone()
        while data:
            return_value.append({
                "type": data["type"],
                "message": data["message"],
                "link": "/notification/" + str(data["id"]) if data["visible"] == 1 else data["link"],
                "visibility": data["visible"]
            })
            data = cur.fetchone()
        return return_value
    except lite.Error as e:
        raise lite.Error from e
    finally:
        if con:
            con.close()

def model__get_notification(id):
    try:
        con = lite.connect('databases/user.db')
        con.row_factory = lite.Row
        cur = con.cursor()
        cur.execute("SELECT * FROM notifications WHERE id=?", (id, ))
        data = cur.fetchone()
        return data
    except lite.Error as e:
        raise lite.Error from e
    finally:
        if con:
            con.close()

def model__set_notification_hidden(id):
    try:
        con = lite.connect('databases/user.db')
        con.row_factory = lite.Row
        cur = con.cursor()
        cur.execute("UPDATE notifications SET visible='0' WHERE id=?", (id, ))
        con.commit()
    except lite.Error as e:
        raise lite.Error from e
    finally:
        if con:
            con.close()

def model__try_login(username, password):
    try:
        con = lite.connect('databases/user.db')
        con.row_factory = lite.Row
        cur = con.cursor()
        cur.execute("SELECT * FROM user WHERE name=? AND password=?", (username, sha1(password)))
        data = cur.fetchone()
        if data is None:
            return -3
        elif data["state"] == -2:
            return -4
        else:
            return data['id'];
    except lite.Error as e:
        print(e)
        return -3
    finally:
        if con:
            con.close()


def model__is_enrolled(userid, courseid):
    try:
        con = lite.connect('databases/user.db')
        con.row_factory = lite.Row
        cur = con.cursor()
        cur.execute("SELECT * FROM enrollments WHERE user_id=? AND course_id=?", (userid, courseid))
        data = cur.fetchone()
        return data is not None
    except lite.Error as e:
        return False
    finally:
        if con:
            con.close()

def model__do_enroll(userid, courseid):
    try:
        con = lite.connect('databases/user.db')
        con.row_factory = lite.Row
        cur = con.cursor()
        cur.execute("INSERT INTO enrollments (user_id, course_id) VALUES(?, ?)", (userid, courseid))
        con.commit()
    except lite.Error as e:
        return False
    finally:
        if con:
            con.close()

def model___set_user_info(userid, field, value):
    try:
        con = lite.connect('databases/user.db')
        con.row_factory = lite.Row
        cur = con.cursor()
        cur.execute("UPDATE user SET "+field+"=? WHERE id=?", (value, userid))
        con.commit()
        return True
    except lite.Error as e:
        return False
    finally:
        if con:
            con.close()


def view_user(stop, value):
    if not value.startswith("id="):
        abort(400)
    value = value[len("id="):]
    try:
        value = int(value)
    except:
        abort(400)
    data = model__get_user_info(value)
    if data is None or (data["state"] == -2 and stop["userrole"] not in ["a", "m"]):
        abort(400)
    return render_template("user/view.html", data=data, stop=stop, title="Benutzer " + data['name'])

def set_user(stop, value):
    data = request.json
    if not "new_value" in data.keys():
        abort(400)
    if not "userid" in data.keys():
        abort(400)
    uid = data["userid"]
    if uid < 0:
        abort(400)
    if stop["userrole"] != "a" and uid != stop["userid"]:
        abort(403)
    if stop["userrole"] == "a" and value in ["name", "reputation"]:
        new_value = data["new_value"]
        print(model___set_user_info(uid, value, new_value))
    elif value in ["realname", "email"]:
        new_value = data["new_value"]
        model___set_user_info(uid, value, new_value)
    elif value == "password":
        new_value = data["new_value"]
        model___set_user_info(uid, "password", sha1(new_value))
    return "ok"


views = {
    "view": view_user,
    "set": set_user
}